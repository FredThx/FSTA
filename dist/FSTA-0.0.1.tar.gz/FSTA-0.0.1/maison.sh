#! /bin/sh
cd /home/pi/maison
python main.py 
