#! /bin/sh
cd /opt/FSTA
python main.py 
